export const API_BASE_URL = 'http://localhost:1234/api';
export const API_ROUTES = {
    producto: `${API_BASE_URL}/producto`,
    proveedor: `${API_BASE_URL}/proveedor`,
    venta: `${API_BASE_URL}/venta`,
    ordenCompra: `${API_BASE_URL}/orden-compra`,
    inventario: `${API_BASE_URL}/inventario`
}; 
import { DataTypes } from 'sequelize';
import db from '../db/connection.mjs';
import inventario from './inventario.mjs';
import proveedor from './proveedor.mjs';

const ordenCompra = db.define('orden_compra', {
    idorden_compra: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    idinventario: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'inventario',
            key: 'idinventario'
        }
    },
    idproveedor: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'proveedor',
            key: 'idproveedor'
        }
    },
    descripcionordendecompra: {
        type: DataTypes.STRING(255)
    },
    estadoorden: {
        type: DataTypes.ENUM('PENDIENTE', 'ENVIADA', 'FINALIZADA', 'CANCELADA'),
        defaultValue: 'PENDIENTE'
    },
    cantidadsolicitada: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    fechaorden: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    }
}, {
    timestamps: false,
    tableName: 'orden_compra'
});

ordenCompra.belongsTo(inventario, {
    foreignKey: 'idinventario'
});

ordenCompra.belongsTo(proveedor, {
    foreignKey: 'idproveedor'
});

export default ordenCompra; 
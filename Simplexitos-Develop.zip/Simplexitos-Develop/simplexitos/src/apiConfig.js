
export const serverFront = 'http://localhost:1234';

export default serverFront;